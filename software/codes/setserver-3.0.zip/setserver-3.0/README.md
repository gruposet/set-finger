# setserver
SET-FINGER server
