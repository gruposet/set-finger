<?php
session_start();
include_once("seguranca.php");
echo "Bem vindo administrativo ".$_SESSION['usuarioNome'];
?>